// Crée un array vide appelé 'toDoItems'
// Votre code ici :

let toDoItems = [];

// dans la page Web 'index.html' il y a un élément span dont le texte est 'Application créée par:'.
// À l'aide de querySelector, sélectionnez la dite span par son id ('createdBy') puis en utilisant innerHTML
// ajoutez votre nom à la fin du texte actuel. Ej: 'Application créée par Webster'
// Votre code ici :

const spanElement = document.querySelector("#createdBy");
spanElement.innerHTML += "Mackendy Bouquet";

/*créez une fonction appelée 'ToDo' et elle doit recevoir un seul paramètre de type string 
avec le nom 'description' et à l'intérieur de la fonction nous devons
ajouter this.description = description et this. complete = false
Cela signifie que la propriété description doit être égale à la description passée en paramètre 
et que la propriété complete doit être définie comme false.*/

function ToDo(description) {
  this.description = description;
  this.complete = false;
}

/*ajoutez une méthode 'completeTodo' au prototype de la fonction
Todo qui sera égale à une fonction et à l'intérieur de cette fonction nous allons ajouter
this. complete = true*/

function ToDo(description) {
  this.description = description;
  this.complete = false;
}

ToDo.prototype.completeTodo = function () {
  this.complete = true;
};

/*creer une fonction qui s'appelle buildTodo e ajouter deux parametres a cette fonction le premier paramètre c'est todo et l autre c'est index puis a l interieur de de cette fonction
1-creez un élément div et attribuez-le à une variable nommée todoShell
2-attribuez a todoShell une classe qui s appelle todoShell ex: todoshell. className = "todoShell'
3-creez un élément span et affectez-le à une variable nommée todoText
4-puis utlizer todoText. innerHtml = todo.description
5-attribuez-l'id de todoText égale a index*/

//todoText.addEventListener("click", completeTodo);

/*6-puis utlizez cette condition if (todo. complete) todoText.className = "completeText"
7-attribuez todoText comme l'enfant de todoShell en utilisant appendChild
8-puis retouner la variable todoShell en utilisant le mot return.*/

function buildTodo(todo, index) {
  const todoShell = document.createElement("div");
  todoShell.className = "todoShell";

  const todoText = document.createElement("span");
  todoText.innerHTML = todo.description;
  todoText.id = index;
  todoText.addEventListener("click", completeTodo);

  if (todo.complete) {
    todoText.className = "completeText";
  }

  todoShell.appendChild(todoText);

  return todoShell;
}

/*creer une fonction qui s'appelle 'buildTodosipuis ajouter un parametre a cette fonction dont le nom est "todos"
á l interieur de cette fonction ajouter cette commande : return todos.map(buildTodo)*/

function buildTodos(todos) {
  return todos.map(buildTodo);
}

//creer une fonction qui s´appelle 'buildTodos'puis ajouter un parametre a cette fonction dont le nom est "todos"
//á l interieur de cette fonction ajouter cette commande : return todos.map(buildTodo)

function buildTodos(todos) {
  return todos.map(buildTodo);
}

//Creer une autre fonction qui s´appelle displayToDos
//a l´interieur cette fonction sélectionner l´element dont l´id est toDoContainer en l´attribuant a la variable : let toDoContainer = ................
//puis ajouter toDocontainer.innerHtml = ""
//utiliser la fonction "buildTodos"puis addicionner toDoItems comme parametre a cette fonction:  let build =  buildTodos(toDOItems)
// ajouter cette commande :
//for(let i = 0; 1 < build.lenght;i++){
//toDOContainer.appendChild(build[i])
//}

function displayToDos(toDoItems) {
  let toDoContainer = document.getElementById("toDoContainer");
  toDoContainer.innerHTML = "";

  let build = buildTodos(toDoItems);

  for (let i = 0; i < build.length; i++) {
    toDoContainer.appendChild(build[i]);
  }
}

//creer une autre fonction qui s´appelle addTodo()
//a l´interieur de cette fonction utliser cette commande let newTodo = new Todo(inputValue.value)
//puis utiliser cette commande : toDOItems.push(newTodo)
//ensuite utiliser : inputValue.value = ""
//pour terminer ajouter : displayTodos()

function addTodo() {
  let newTodo = new Todo(inputValue.value);
  toDoItems.push(newTodo);
  inputValue.value = "";
  displayTodos();
}

//ceer une variable qui s´appelle let addButton et attribuer a cette variable  la valeur de document.querySelector("#Button")
//Exemple  let assButton = document.querySelector("#Button")
//puis utiliser cette commande : addButton.addEventListener('click', addTodo)

let addButton = document.querySelector("#Button");
addButton.addEventListener("click", addTodo);

//retourner a la fonction build todo et utiliser cette commande juste apres la cinquieme ligne: todoText.addEventListener('click' , completeTodo)

//pour terminer ajouter cette fonction

function completeTodo(event) {
  const index = event.target.id;
  toDoItems[index].completeTodo();
  displayToDos();
}
